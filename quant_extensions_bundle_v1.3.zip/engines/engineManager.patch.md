// EngineManager toggle snippet (v1.3)
// Merge into your existing engineManager.js constructor defaults:
//
// this.enabled.seatAdjustedPair = true;
// this.enabled.dealerUpcardPairModel = true;
// this.enabled.cbsFilter = true;
// this.enabled.portfolioSelector = true;
// this.enabled.kellyGovernor = true;
// this.enabled.temporalOptimizer = true;
// this.enabled.windowDetector = true; // already exists
